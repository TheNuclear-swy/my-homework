import turtle
import datetime
import math


def drawGap():             
    turtle.penup()
    turtle.fd(5)

def drawLine(up):       
    drawGap()
    turtle.pendown()
    turtle.begin_fill() if up else None
    turtle.lt(45)
    turtle.fd(math.sqrt(18))
    turtle.rt(45)
    turtle.fd(34)
    turtle.rt(45)
    turtle.fd(math.sqrt(18))
    turtle.rt(90)
    turtle.fd(math.sqrt(18))
    turtle.rt(45)
    turtle.fd(34)
    turtle.rt(45)
    turtle.fd(math.sqrt(18))
    turtle.end_fill() if up else None
    turtle.rt(135)
    turtle.pu()
    turtle.fd(40)
    drawGap()
    turtle.rt(90)

def realDraw(num, a):
    if num in a:
        drawLine(True)
    else:
        drawLine(False)

def drawNumber(num, dot):
    turtle.color("red")
    turtle.setup(1000, 350, 200, 200)
    turtle.penup()
    turtle.fd(-400)
    turtle.pensize(1)
    turtle.speed(10)
    num_list = [int(i) for i in str(num)]

    for n in num_list:
        #for i in num:
        realDraw(n, [2,3,4,5,6,8,9])
        realDraw(n, [0,1,3,4,5,6,7,8,9])
        realDraw(n, [0,2,3,5,6,8,9])
        if dot:
            turtle.pendown()
            turtle.fd(5)
            turtle.penup()
            turtle.fd(-5)
        realDraw(n, [0,2,6,8])
        turtle.lt(90)
        realDraw(n, [0,4,5,6,8,9])
        realDraw(n, [0,2,3,5,6,7,8,9])
        realDraw(n, [0,1,2,3,4,7,8,9])
        turtle.penup()
        turtle.lt(180)
        turtle.fd(20)
        turtle.fd(100)
    turtle.bye()

def drawChose(date):
    turtle.color("red")
    for i in date:
        if i == '-':
            turtle.write('年', font=("Arial", 60, "normal"))
            turtle.pencolor("green")
            turtle.fd(100)
        elif i == '=':
            turtle.write('月', font=("Arial", 60, "normal"))
            turtle.pencolor("yellow")
            turtle.fd(100)
        elif i == '+':
            turtle.write('日',font=("Arial", 60, "normal"))
        elif i == '.':
            drawNumber(i,True)
        else:
            drawNumber(eval(i), False)


def drawHandle(idx):

    if idx == 1:
        try:
            Number = int(input("请输入你想显示的数字"))
            print(Number)
            drawNumber(Number,True)
            turtle.Turtle._screen = None  # force recreation of singleton Screen object
            turtle.TurtleScreen._RUNNING = True  # only set upon TurtleScreen() definition

        except SyntaxError:
            print("输入错误,请输入数字!")

    elif idx == 2:
        now_time = datetime.datetime.now().strftime('%H:%M').split(':')
        Number = int(now_time[1])
        Number += 100*int(now_time[0])
        drawNumber(Number,True)
        turtle.Turtle._screen = None  # force recreation of singleton Screen object
        turtle.TurtleScreen._RUNNING = True  # only set upon TurtleScreen() definition

    # elif idx == 3:
    #     drawDate(datetime.datetime.now().strftime('%Y-%m=%d+'))
    #     turtle.bye()
    #
    # elif idx == 2:
    #     datestr = str(input("请输入想显示的时间"))
    #     drawDate(datestr)
    #     turtle.bye()
