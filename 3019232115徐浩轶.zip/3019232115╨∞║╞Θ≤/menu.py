from logging import exception
from operator import truediv
from xml.dom import INDEX_SIZE_ERR
import drawSevendisplay
import Hash_Function
import turtle
from drawSevendisplay import drawHandle
from statistic_code import sta_code

def my_draw():
    turtle.setup(650, 350, 200, 200)
    turtle.penup()
    turtle.fd(-250)
    turtle.pendown()
    turtle.pensize(25)
    turtle.pencolor("purple")
    turtle.seth(-40)
    for i in range(4):
        turtle.circle(40, 80)
        turtle.circle(-40, 80)
    turtle.circle(40, 80/2)
    turtle.fd(40)
    turtle.circle(16, 180)
    turtle.fd(40 * 2/3)
    turtle.done()

menu0 = '''
        主菜单
==========================
1：绘图程序

2：哈希函数

3：7段数码管

4：保留字统计

0：退出程序
==========================
'''

# 绘图
def myDraw():
    my_draw()
    #returnToMain()
# 哈希
def myHesh():
    Hash_Function.main()
    returnToMain()
# # 数码管
def mySeg():
    while True:
        form=int(input("显示数字还是时间？\n1.数字\n2.时间\n0.返回主菜单"))
        print(form)
        if form==0:
             break
        elif form == 1:
            drawHandle(1)
        else:
            drawHandle(2)
        #except Exception:
        #    print("输入错误！请重新输入！")
# def mySeg():
#     flag = 0
#     while True:
#         try:
#             idx=int(input('显示数字还是时间？\n1.数字\n2.时间\n3.日期\n0.返回主菜单'))
#             if idx == 1 or idx == 2 or idx ==3 :
#                 drawSevendisplay.main(idx)
#                 flag = 1
#                 returnToMain()
#                 break
#         except Exception:
#             print('error')
#         if flag ==1:
#             break
# 作业4
def my4():
    print('功能尚待开发！')
    returnToMain()

def returnToMain():
    while True:
        try:
            mc2 = int(input('按0返回主菜单\n'))
            if mc2 == 0:
                break
        except Exception:
            print('输入错误!请重新输入！')

def run():
    
    while True:
        print(menu0,end=" ")

        mc1 = int(input('请输入菜单号：'))
        if mc1 == 1:
            myDraw()
        elif mc1 == 2:
            myHesh()
        elif mc1 == 3:
             mySeg()
        elif mc1 == 4:
            print(sta_code())
        elif mc1 == 0:
            print('谢谢使用！')
            break

                
def main():

    run()
    
main()