def fun():
    print(hash('hello'))
    print(hash(str([1,2,3,])))
    print(hash(1))
def main():
    fun()
