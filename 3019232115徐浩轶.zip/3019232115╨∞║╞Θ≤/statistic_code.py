import keyword
def sta_code():
    key = keyword.kwlist
    s_list = {}
    for k in key:
        s_list[k] = 0

    with open('menu.py','r',encoding='utf-8') as f:
        for line in f:
            words = line.split(' ')
            for w in words:
                if w in s_list:
                    s_list[w] += 1
    with open('Hash_Function.py','r',encoding='utf-8') as f:
        for line in f:
            words = line.split(' ')
            for w in words:
                if w in s_list:
                    s_list[w] += 1
    with open('drawSnake.py','r',encoding='utf-8') as f:
        for line in f:
            words = line.split(' ')
            for w in words:
                if w in s_list:
                    s_list[w] += 1
    with open('drawSevendisplay.py','r',encoding='utf-8') as f:
        for line in f:
            words = line.split(' ')
            for w in words:
                if w in s_list:
                    s_list[w] += 1
    return (s_list)

print(sta_code())